﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;


//@Author Tebogo Ngwenya
namespace UITest.UserDefinedFunctions
{

    public class Actions
    {

        // reusable driver instance     
        public static IWebDriver driver = default!;

        //Reusable method to open the chrome browser
        public static void OpenChromeBrowser(string url)
        {
            driver = new ChromeDriver();
            // This will open up the Lumina site
            driver.Url = url;
            driver.Manage().Window.Maximize();
            Thread.Sleep(10000);

        }
        //Reusable method to capture values in the input box field
        //Note: 'element' variable only accepts xpath as a value.
        public static void InputText(string targetXpath, string text)
        {
            driver.FindElement(By.XPath(targetXpath)).Clear();
            driver.FindElement(By.XPath(targetXpath)).SendKeys(text);
            Thread.Sleep(1000);

        }
        //Reusable method to click any element on the web page
        public static void ClickElement(string targetXpath)
        {
            driver.FindElement(By.XPath(targetXpath)).Click();
            Thread.Sleep(1000);

        }
        //Reusable method to double click any element on the web page
        public static void DoubleClickElement(string targetXpath)
        {
            driver.FindElement(By.XPath(targetXpath)).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath(targetXpath)).Click();
            Thread.Sleep(1000);

        }
        //Reusable method to capture the screenshot on the web page
        public static void CaptureScreenshot(string path)
        {
            //Capture screenshot
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            ss.SaveAsFile(path, ScreenshotImageFormat.Png);

        }
        

        

    }
}