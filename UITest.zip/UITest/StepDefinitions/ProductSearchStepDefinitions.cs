using System;
using UITest.PageObjects;
using TechTalk.SpecFlow;
using UITest.UserDefinedFunctions;

namespace UITest.StepDefinitions
{
    [Binding]
    public class ProductSearchStepDefinitions : Validations
    {
        
        [Given(@"User Navigates to shoprite site as ""([^""]*)""")]
        public static void GivenUserNavigatesToShopriteSiteAs(string p0)
        {
            OpenChromeBrowser (p0);
        }

        [When(@"User search for a product as ""([^""]*)""")]
        public static void WhenUserSearchForAProductAs(string tomato)
        {
            WaitUntilElementIsVisible(ProductSearchPageObjects.GetSearchField(), 3);
            InputText(ProductSearchPageObjects.GetSearchField(), tomato);
            ClickElement(ProductSearchPageObjects.GetSearchedProduct());
        }

        [Then(@"User verifies the product price and description")]
        public static void ThenUserVerifiesTheProductPriceAndDescription()
        {
            WaitUntilElementIsVisible(ProductSearchPageObjects.GetProductPrice(), 1);
            WaitUntilElementIsVisible(ProductSearchPageObjects.GetProductPrice(), 1);

        }

        [Then(@"User verifies that product information is displayed")]
        public static void ThenUserVerifiesThatProductInformationIsDisplayed()
        {
            
        }
    }
}
