﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UITest.PageObjects
{
    internal class ProductSearchPageObjects
    {
        public static string GetSearchField()
        {
            return "//input[@placeholder='Search']";
        }
        public static string GetSearchedProduct()
        {
            return "//*[@id=/'ui-id-18/']/div/div[1]/span[2]/div/span[1]";
        }
        public static string GetProductPrice()
        {
            return "/html/body/googletagmanager:iframe/main/header/div[3]/div[2]/div[2]/div/div[3]/div[1]/div[1]/ul/li[5]/a/div/div[1]/span[2]/div/span[2]";
        }
        public static string GetProductDescription()
        {
            return "//h1[@class='pdp__name']";
        }

        


    }
}
